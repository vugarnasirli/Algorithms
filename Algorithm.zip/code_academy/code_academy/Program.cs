﻿using System;

namespace code_academy
{
    class Program
    {
        static void Main(string[] args)
        {
            //calculator calculator = new calculator();
            //Console.WriteLine("Please enter first number:");
            //calculator.FirstNumber = decimal.Parse(Console.ReadLine());
            //Console.WriteLine("Please enter second number:");
            //calculator.SecondNumber = decimal.Parse(Console.ReadLine());
            //Console.WriteLine("Please enter symbol:");
            //calculator.Symbol = char.Parse(Console.ReadLine());
            //Console.WriteLine(calculator.calculate());
            //Console.ReadKey();

            //string name = "Elabbas";
            //Console.WriteLine(name.Substring(3,4));
            //Console.ReadKey();

        }
    }
}
