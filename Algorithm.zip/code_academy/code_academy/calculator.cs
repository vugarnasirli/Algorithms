﻿namespace code_academy
{
    class calculator
    {
        public decimal FirstNumber;
        public decimal SecondNumber;
        public char Symbol;
        public decimal result;


        public decimal calculate()
        {
            switch (Symbol)
            {
                case '+': result = Add(FirstNumber, SecondNumber); break;
                case '-': result = Sub(FirstNumber, SecondNumber); break;
                case '*': result = Mul(FirstNumber, SecondNumber); break;
                case '/': result = Div(FirstNumber, SecondNumber); break;


            }

            return result;

        }

        public decimal Add(decimal firstNumber, decimal secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public decimal Sub(decimal firstNumber, decimal secondNumber)
        {
            return firstNumber - secondNumber;
        }
        public decimal Div(decimal firstNumber, decimal secondNumber)
        {
            return firstNumber / secondNumber;
        }
        public decimal Mul(decimal firstNumber, decimal secondNumber)
        {
            return firstNumber * secondNumber;
        }
    }
}
