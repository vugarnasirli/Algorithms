﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace string_method
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Hesen Memmedov";
            
            myString myString = new myString();
            myString.Str = str;
            
            Console.WriteLine(myString.Replace("Memmedov","Vugar"));
            Console.ReadLine();
            
            ;
        }
    }
}
