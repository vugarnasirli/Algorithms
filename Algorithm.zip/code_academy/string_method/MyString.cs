﻿using System;

namespace string_method
{
    class myString
    {
        public string Str;

        public int GetLength()
        {
            int count = 0;
            foreach (char i in Str)
            {
                count++;
            }
            return count;
        }


        public string Substring(int fromIndex, int count)
        {
            string Newstring = string.Empty;
            
            
            
                for (int i = fromIndex; i <count; i++)
                {
                    Newstring += Str[i];
                }
            
            return Newstring;
        }

        public int IndexOf(string phrase)
        {
            int index = -1;
            for(int i=0; i<= Str.Length - phrase.Length; i++)
            {
                if(Substring(i,phrase.Length) == phrase)
                {
                    index = i;
                    break;
                }
            }
            return index;

        }

        public bool Contains (string phrase)
        {
            bool _contain = false;
            for(int i=0; i<= Str.Length -phrase.Length; i++)
            {
                if(Substring(i,phrase.Length) == phrase)
                {
                    _contain = true;
                    break;

                }
            }
            return _contain;
        }


        public string Insert(int startIndex, string value)
        {
            string insertFrom = Substring(0, startIndex);
            string insertLast = Substring(startIndex, Str.Length);
            string newStr = string.Empty;
            for (int i = 0; i < Str.Length;i++)
            {
                newStr = $"{insertFrom}{value}{insertLast}";
            }
            return newStr;
    }

        public string Remove( int index)
        {
            string newStr = Substring(0, index);
            return newStr;
        }

        public string RemoveDouble(int index, int to)
        {
            string newStr = string.Empty;
            newStr = $"{Substring(0, index)}{Substring(Str.Length - to, Str.Length)}";

                return newStr;
        }
        
        public string PadLeft (int index, string value)
        {
            string newStr = string.Empty;
            int valueNum = index - Str.Length;
            for(int i=0; i< valueNum;i++)
            {
                newStr +=value;
            }
            return $"{newStr}{Str}";
            
        }

        public string PadRight (int index, string value)
        {
            string newStr = string.Empty;
            int valueNum = index - Str.Length;
            for (int i = 0; i < valueNum; i++)
            {
                newStr += value;
            }
            return $"{Str}{newStr}";
        }

        public bool StartWith ( string value)
        {
           bool newStr = false;

            if(Substring(0,value.Length) == value)
            {
                newStr = true;
            }

            return newStr;
        }

        public bool EndWith(string value)
        {
            bool newStr = false;

            if (Substring(Str.Length-value.Length, Str.Length) == value)
            {
                newStr = true;
            }

            return newStr;
        }

        public string Replace(string OldValue, string value)
        {
           
            string LeftSide = Str.Substring(0, Str.IndexOf(OldValue));
            string RightSide = Str.Substring(Str.IndexOf(OldValue)+OldValue.Length);

            

            
            return $"{LeftSide}{value}{RightSide}";
        }

        public int LastIndexOf(string value)
        {
            if (Contains(value))
            {

            }

            return 0;
        }



        

    }

   








}
